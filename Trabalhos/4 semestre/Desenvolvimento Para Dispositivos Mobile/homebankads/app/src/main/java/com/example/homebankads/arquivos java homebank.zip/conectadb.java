package com.example.homebankads;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class conectadb extends SQLiteOpenHelper {

    String tab_usr = "CREATE TABLE IF NOT EXISTS usuario (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "login TEXT," +
            "senha TEXT," +
            "saldo NUMERIC)";

    conectadb(Context contexto) {

        super(contexto, "homebankdb", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(tab_usr);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String RECRIA = "DROP TABLE IF EXISTS usuario";
        sqLiteDatabase.execSQL(RECRIA);
        onCreate(sqLiteDatabase);
    }
}
